
/**
 * Write a description of class Heater here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Heater
{
    // instance variables - replace the example below with your own
    private double temperature;
    private double min;
    private double max;
    private double increment;

    /**
     * Constructor for objects of class Heater
     */
    public Heater(double minimum, double maximum)
    {
        // initialise instance variables
        temperature = 15.0;
        min = minimum;
        max = maximum;
        increment = 5.0;
    }

    /**
     * Takes 5.0 from temperature.
     */
    public void cooler()
    {
        if((temperature-increment) >= min){
            temperature -= increment;
        }
        else{
            temperature = min;
        }
    }
    
    /**
     * Adds 5.0 to temperature.
     */
    public void warmer()
    {
        if((temperature+increment) <= max){
            temperature += increment;
        }
        else{
            temperature = max;
        }
    }
    
    /**
     * Returns the value of temperature.
     */
    public double getTemp()
    {
        return temperature;
    }
    
    /**
     * Sets the value of increment.
     */
    public void setIncrement(double amount)
    {
        if(amount > 0){
            increment = amount;
        }
        else{
            System.out.println("Amount must be greater than 0.");
        }
    }
}

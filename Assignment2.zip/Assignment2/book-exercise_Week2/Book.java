/**
 * A class that maintains information on a book.
 * This might form part of a larger application such
 * as a library system, for instance.
 *
 * @author (Insert your name here.)
 * @version (Insert today's date here.)
 */
class Book
{
    // The fields.
    private String author;
    private String title;
    private String refNumber;
    private int pages;
    private int borrowed;
    private boolean courseText;

    /**
     * Set the author and title fields when this object
     * is constructed.
     */
    public Book(String bookAuthor, String bookTitle, int bookPages, boolean courseCheck)
    {
        author = bookAuthor;
        title = bookTitle;
        refNumber = "";
        pages = bookPages;
        courseText = courseCheck;
    }

    // Add the methods here ...
    /**
     * Checks whether a text book is used in a course.
     */
    public boolean isCourseText()
    {
        return courseText;
    }
    
    /**
     * Mutator method for borrowed
     */
    public void borrow()
    {
        borrowed += 1;
        System.out.println("Book has been borrowed.");
    }
    
    /**
     * Mutator method for borrowed
     */
    public int getBorrowed()
    {
        return borrowed;
    }
    
    /**
     * Returns the author of the book.
     */
    public String getAuthor()
    {
        return author;
    }
    
    /**
     * Mutator method for refNumber.
     */
    public void setRefNumber(String ref)
    {
        if(ref.length() >= 3){
        refNumber = ref;
    }
        else{
        System.out.println("Reference Number must be at least 3 characters.");
    }
    }
    
    /**
     * Returns refNumber.
     */
    public String getRefNumber()
    {
        return refNumber;
    }
    
    /**
     * Returns the title of the book.
     */
    public String getTitle()
    {
        return title;
    }
    
    /**
     * Retun the number of pages in the book.
     */
    public int getPages()
    {
        return pages;
    }
    
    /**
     * Prints the author of the book.
     */
    public void printAuthor()
    {
        System.out.println("The author of the book is " + author + ".");
    }
    
    /**
     * Prints the title of the book.
     */
    public void printTitle()
    {
        System.out.println("The title of the book is " + title + ".");
    }
    
    /**
     * Prints the information about the book.
     */
    public void printDetails()
    {
        if(refNumber.length() > 0){
        System.out.println("Author: " + author + ", Title: " + title + ", Pages: " + pages + ", Reference Number: " + refNumber);
        System.out.println("This book has been borrowed " + borrowed + " times.");
    }
    else{
        System.out.println("Author: " + author + ", Title: " + title + ", Pages: " + pages + ", Reference Number: ZZZ");
        System.out.println("This book has been borrowed " + borrowed + " times.");
    }
    }
}

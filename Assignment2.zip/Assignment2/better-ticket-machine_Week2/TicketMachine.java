/**
 * TicketMachine models a ticket machine that issues
 * flat-fare tickets.
 * The price of a ticket is specified via the constructor.
 * Instances will check to ensure that a user only enters
 * sensible amounts of money, and will only print a ticket
 * if enough money has been input.
 * 
 * @author David J. Barnes and Michael Kölling
 * @version 2016.02.29
 */
public class TicketMachine
{
    // The price of a ticket from this machine.
    private double price;
    // The amount of money entered by a customer so far.
    private double balance;
    // The total amount of money collected by this machine.
    private double total;
    // Checks to see if a ticket has been discounted.
    private int discounted;

    /**
     * Create a machine that issues tickets of the given price.
     */
    public TicketMachine(int cost)
    {
        price = cost;
        balance = 0;
        total = 0;
        discounted = 1;
    }

    /**
     * @Return The price of a ticket.
     */
    public double getPrice()
    {
        return price;
    }

    /**
     * Return The amount of money already inserted for the
     * next ticket.
     */
    public double getBalance()
    {
        return balance;
    }

    /**
     * Receive an amount of money from a customer.
     * Check that the amount is sensible.
     */
    public void insertMoney(int amount)
    {
        if(amount <= 0) {
            System.out.println("Use a positive amount rather than: " +
                               amount);
        }
        else {
            balance = balance + amount;
        }
    }

    /**
     * Print a ticket if enough money has been inserted, and
     * reduce the current balance by the ticket price. Print
     * an error message if more money is required.
     */
    public void printTicket()
    {
        double amountLeftToPay = price - balance;
        double discount = .85;
        
        if(amountLeftToPay <= 0) {
            // Simulate the printing of a ticket.
            System.out.println("##################");
            System.out.println("# The BlueJ Line");
            System.out.println("# Ticket");
            System.out.println("# " + price + " cents.");
            System.out.println("##################");
            System.out.println();

            // Update the total collected with the price.
            total = total + price;
            // Reduce the balance by the price.
            balance = balance - price;
            // Resets discount for a new customer.
            discounted = 1;
            // Resets the price of the ticket before the discount.
            price = price / discount;
        }
        else {
            System.out.println("You must insert at least: " +
                               amountLeftToPay + " more cents.");
                    
        }
    }

    /**
     * Gives a discount on the price of a ticket.
     */
    public void giveDiscount()
    {
        if(discounted == 1){
            double discount = 0.85;
            price = price * discount;
            discounted = 2;
            System.out.println("Price is now " + price + " cents.");
        }
        else{
            System.out.println("You have already received a discount.");
        }
    }
    
    /**
     * Empties the machine of money and returns how much was in it.
     */
    public double emptyMachine()
    {
        double amountEarned = total;
        total = 0;
        return amountEarned;
    }
    
    /**
     * Return the money in the balance.
     * The balance is cleared.
     */
    public double refundBalance()
    {
        double amountToRefund;
        amountToRefund = balance;
        balance = 0;
        return amountToRefund;
    }
}

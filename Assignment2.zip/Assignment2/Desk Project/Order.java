
/**
 * Customer order details.
 *
 * @author Doug Heinbokel
 * @version 1.0
 */
public class Order
{
    // instance variables
    private String orderNum;
    private String custName;
    private String wood;
    private int length;
    private int width;
    private int drawerNum;
    private int drawerPrice;
    private double price;
    
    /**
     * Constructor for objects of class Order
     */
    public Order(String orderNumber, String name)
    {
        // initialise instance variables
        orderNum = orderNumber;
        custName = name;
        wood = "";
        length = 0;
        width = 0;
        drawerNum = 0;
        drawerPrice = 30;
        price = 200;
    }

    /**
     * Input wood type. Options are "pine" or "oak" or "mahogany" which must be lowercase.
     */
    public void chooseWood(String type)
    {
        //Options are "pine" or "oak" or "mahogany" which must be lowercase.
        if(type == "pine"){
            System.out.println("You choose pine, no extra charge.");
            wood = type;
        }
        else if(type == "oak"){
            System.out.println("You choose oak, there is a $125 charge.");
            wood = type;
        }
        else if(type == "mahogany"){
            System.out.println("You choose mahogany, there is a $150 charge.");
            wood = type;
        }
        else{
            System.out.println("Sorry, that is not an option.");
        }
    }
    
    /**
     * Input size of desk. Enter length in inches then width in inches.
     */
    public void chooseSize(int deskLength, int deskWidth)
    {
        //Enter length in inches then width in inches.
        if(deskLength > 0 && deskWidth > 0){
            length = deskLength;
            width = deskWidth;
            int area = length * width;
            if(area > 750){
                System.out.println("Your desk is over 750 sq inches, a $50 charge will be added..");
            }
        }
        else{
            System.out.println("Amount must be greater than 0.");
        }
    }
    
    /**
     * Input number of drawers. Enter amount of drawers you would like.
     */
    public void setDrawerNum(int drawers)
    {
        //Enter amount of drawers you would like.
        if(drawers > 0){
            drawerNum = drawers;
            System.out.println("You choose to have " + drawerNum + " drawers.");
        }
        else{
            System.out.println("You must have more than 0 drawers, or it's just a table...");
        }
    }
    
    /**
     * Print out final price and reset all fields for another item.
     */
    public void printReceipt()
    {
        if(wood == "" || width == 0 || length == 0 || drawerNum == 0){
            System.out.println("You must finish your order before printing.");
        }
        else{
            price += (drawerNum * drawerPrice);
            if(wood == "pine"){
                price += 0;
            }
            else if(wood == "oak"){
                price += 125;
            }
            else{
                price += 150;
            }
        
            int area = length * width;
            if(area > 750){
                price += 50;
            }
            
            System.out.println("Order #:" + orderNum + ", Customer Name: " + custName);
            System.out.println("Wood Type: " + wood);
            System.out.println("Length: " + length);
            System.out.println("Width: " + width);
            System.out.println("Number of Drawers: " + drawerNum);
            System.out.println("Final Price: " + price);
            
            //Set fields back to defualt for a new desk order.
            wood = "";
            length = 0;
            width = 0;
            drawerNum = 0;
            price = 200;
        }
    }
}
